package com.rk.deviceinfo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var out: TextView
    private lateinit var previewView: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val requiredPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA
    )

    private val requestPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        startCameraIfPossible()
        showDeviceInfo()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        val sv = ScrollView(this)
        out = TextView(this).apply {
            textSize = 14f
            setPadding(20,20,20,20)
        }
        sv.addView(out)
        previewView = PreviewView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 600)
            visibility = View.GONE
        }
        val refreshBtn = Button(this).apply {
            text = "Refresh Info"
            setOnClickListener { showDeviceInfo() }
        }

        root.addView(previewView)
        root.addView(sv)
        root.addView(refreshBtn, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = 24; topMargin = 24
        })

        setContentView(root)

        cameraExecutor = Executors.newSingleThreadExecutor()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        askPermissionsIfNeeded()
    }

    private fun askPermissionsIfNeeded() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPerms.launch(missing.toTypedArray())
        } else {
            startCameraIfPossible()
            showDeviceInfo()
        }
    }

    private fun startCameraIfPossible() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { previewView.visibility = View.GONE }
            return
        }
        runOnUiThread { previewView.visibility = View.VISIBLE }
        // CameraX binding omitted in this minimal starter; add binding in real project.
    }

    private fun showDeviceInfo() {
        val sb = StringBuilder()
        sb.appendLine("=== Device Info ===")
        sb.appendLine("Manufacturer: ${'$'}{Build.MANUFACTURER}")
        sb.appendLine("Model: ${'$'}{Build.MODEL}")
        sb.appendLine("Brand: ${'$'}{Build.BRAND}")
        sb.appendLine("Device: ${'$'}{Build.DEVICE}")
        sb.appendLine("Android Version: ${'$'}{Build.VERSION.RELEASE} (SDK ${'$'}{Build.VERSION.SDK_INT})")
        sb.appendLine("Android ID: ${'$'}{Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)}")
        sb.appendLine()
        val pm = packageManager
        sb.appendLine("=== Cameras ===")
        sb.appendLine("Has camera: ${'$'}{pm.hasSystemFeature(PackageManager.FEATURE_CAMERA)}")
        sb.appendLine("Has front camera: ${'$'}{pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)}")
        sb.appendLine()
        sb.appendLine("=== Sensors (presence) ===")
        sb.appendLine("GPS: ${'$'}{pm.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS)}")
        sb.appendLine("Accelerometer: ${'$'}{pm.hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER)}")
        sb.appendLine()
        sb.appendLine("=== Permissions ===")
        for (p in requiredPermissions) {
            val granted = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
            sb.appendLine("${'$'}p : ${'$'}granted")
        }
        out.text = sb.toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
